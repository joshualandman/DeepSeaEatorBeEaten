﻿using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour {
	//declare size numbers
	public float bodySize;
	public float headSize;
	
	void Start()
	{

	}
}